# Passage S18 vers S19

Copie de travail préparée le 22 novembre 2026 depuis le dossier commun de S18.
Statut : À COMPLÉTER. Aucune observation ni validation n’est présumée.

- [ ] Rouvrir le carnet S17 : HTML, CSS, JavaScript et navigateur.
- [ ] Rouvrir les sources, le cadrage, le prompt maître et le pack de production S18.
- [ ] Conserver le pack S18 avant modification et nommer la version S19.
- [ ] Assembler la page V1 et joindre sa fiche dans `04-WEB/pieces`.
- [ ] Copier tout le dossier, le déplacer et faire essayer la page et son lien.
- [ ] Renseigner `06-PORTFOLIO/preuve-S19.md` avec le résultat réel.
- [ ] Explorer `04-WEB/laboratoire-json-S19` depuis un serveur local.
- [ ] Préparer les essais PWA puis le relais S20 ; conserver V1 avant V2.

Le dossier source S18 reste intact. Cette copie ne possède pas de dépôt Git initialisé.
Les instructions de versionnement conservées décrivent le dépôt de référence ; elles ne prouvent pas la présence d’un remote dans cette copie.
