# Contexte local — S19

Productions S18 synchronisées le 23 novembre 2026, sans modification du versionnement. Aucun dépôt Git n’est initialisé dans ce dossier. La présence des fichiers ne prouve pas un push. Initialiser ou rattacher un dépôt nécessite un choix de destination explicite.
